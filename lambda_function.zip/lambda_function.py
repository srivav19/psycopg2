import boto3
import psycopg2
import json
import os

def execute_query(con, cur, script):
    try:
        print("1")
        cur.execute(script)
        con.commit()
        result = cur.fetchall()
    except Exception as e:
        con.rollback()
        result = []
        print(e)
    finally:
        con.close()
    return result


def get_conn_string(db_conn):
    return "dbname='{}' port='5439' user='{}' password='{}' host='{}'".format(
        db_conn['db_name'],
        db_conn['db_username'],
        db_conn['db_password'],
        db_conn['db_host'])


def lambda_handler(event, context):

    client = boto3.client('secretsmanager')
    response = client.get_secret_value(
        SecretId='arn:aws-cn:secretsmanager:cn-north-1:513980351010:secret:UJD-SECRET-CDL-RS-SERVICEACCOUNT-Er1Cdz')
    SecretString = json.loads(response['SecretString'])
    print(SecretString)
    db_username = SecretString['username']
    db_password= SecretString['password']
    print(db_username)
    print(db_password)
    
    db_host=os.envrion['REDSHIFT_HOST_NAME']
    db_name=os.eniron['REDSHIFT_DB_NAME']

    db_conn={
        "db_name": db_name,
        "db_username": db_username,
        "db_password": db_password,
        "db_host": db_host}

    conn_string=get_conn_string(db_conn)
    conn=psycopg2.connect(conn_string)
    s3=boto3.resource('s3', region_name='cn-north-1')

    # bucket = 'ujd-s3-cdl-kpi-data'
    # resp_obj = s3.get_object(Bucket=bucket, key='Project/UJD_RS_DBScript1.sql')
    # resp_obj = s3.Bucket(bucket).Object('Project/UJD_RS_DBScript1.sql')

    client = boto3.client('s3')
    bucket = 'ujd-s3-cdl-kpi-data'
    keys='Project/UJD_RS_DBScript1.sql'
    response=client.get_object(Bucket=bucket,Key=keys)
    script_sql = str(response['Body'].read())
    final_result=execute_query(conn, conn.cursor(), script_sql)
    

